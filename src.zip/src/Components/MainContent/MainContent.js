import React,{Component } from 'react';
import {Row,Col} from 'react-bootstrap';

class MainContent extends Component{
  constructor(props){
    super(props);
    this.state = {
      itemList:{},
      catalogList:[]
    }
  }
  componentDidMount(){
    fetch('https://jsonblob.com/api/72127bc9-509e-11ea-9bed-c1d2eef1045c')
    .then(response => response.json())
    .then(response=>{
        let catalogList = response.map(item => item.category);
        catalogList = [...new Set(catalogList)];
        console.log(catalogList);
        this.setState({
          itemList :[...response],
          catalogList:catalogList
        });
        debugger;

    })
  }
  render(){
    return(
      <Row>
        <pre>{JSON.stringify(this.state.itemList[0],null,2)}</pre>
        
        <h3>This is the catalog</h3>
        <Col>
          {/* <pre>{JSON.stringify(this.state.itemList,null,4)}</pre> */}
        </Col>
      </Row>
    )
  }
}

export default MainContent;