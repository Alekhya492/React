import React,{Fragment} from 'react';
import './Header.css';
import { Row,Col,Form,FormControl,Button,Image } from "react-bootstrap";

const Header= () =>{
    return (
       <Fragment>
           <Row className="header">
               <Col xs={3} className="text-left">
                    <a href="/">
                        <Image className="logo" fluid="true" src="https://www.48hourslogo.com/48hourslogo_data/2016/05/04/51347_1462345744.jpg" alt="logo" roundedCircle />
                    </a>
                </Col>
               <Col xs={6}>
                    <Form inline>
                        <FormControl type="text" placeholder="Search" className=" mr-sm-2" />
                        <Button type="submit"variant="warning" >Go</Button>
                    </Form>
               </Col>
               <Col xs={3} className="text-right">
                    <Button>Sign In</Button>
               </Col>
           </Row>
       </Fragment> 
    )
}

export default Header;